import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

class DBHelper {
  static final DBHelper instance = DBHelper._init();
  static Database? _database;

  DBHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('fitness.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, filePath);
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    // Sleep entries
    await db.execute('''
      CREATE TABLE sleep_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        sleep_time TEXT NOT NULL,
        wake_time TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL,
        note TEXT
      )
    ''');

    // Exercises (preset + custom)
    await db.execute('''
      CREATE TABLE exercises (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        muscle_group TEXT NOT NULL,
        is_custom INTEGER DEFAULT 0
      )
    ''');

    // Workout sessions
    await db.execute('''
      CREATE TABLE workout_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        muscle_groups TEXT,
        note TEXT
      )
    ''');

    // Sets logged for each exercise in a session
    await db.execute('''
      CREATE TABLE workout_sets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        exercise_id INTEGER NOT NULL,
        set_number INTEGER NOT NULL,
        reps INTEGER NOT NULL,
        weight REAL NOT NULL,
        FOREIGN KEY(session_id) REFERENCES workout_sessions(id) ON DELETE CASCADE,
        FOREIGN KEY(exercise_id) REFERENCES exercises(id)
      )
    ''');

    // Notes
    await db.execute('''
      CREATE TABLE notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        title TEXT,
        content TEXT NOT NULL
      )
    ''');

    // Body weight
    await db.execute('''
      CREATE TABLE body_weight (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        weight REAL NOT NULL,
        photo_path TEXT
      )
    ''');

    // Seed default exercises
    await _seedExercises(db);
  }

  Future<void> _seedExercises(Database db) async {
    final exercises = {
      'Chest': ['Incline Bench Press', 'Incline Dumbbell Press', 'Pec Dec Fly', 'Cable Fly', 'Pushups'],
      'Back': ['Lat Pulldown', 'Seated Rows', 'Lat Pull-Over', 'Pull Ups', 'Machine Rows'],
      'Triceps': ['Push Down', 'Overhead Extension', 'Skull Crushers', 'Single Arm Push Down'],
      'Biceps': ['EZ Bar Curls', 'Hammer Curls', 'Lying Bicep Curls'],
      'Shoulders': ['Shoulder Dumbbell Press', 'Overhead Press', 'Cable Lateral Raises', 'Face Pulls', 'Front Raises'],
    };

    for (final group in exercises.keys) {
      for (final ex in exercises[group]!) {
        await db.insert('exercises', {
          'name': ex,
          'muscle_group': group,
          'is_custom': 0,
        });
      }
    }
  }

  // -- SLEEP --
  Future<int> insertSleep(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('sleep_entries', row);
  }

  Future<List<Map<String, dynamic>>> getAllSleep() async {
    final db = await instance.database;
    return await db.query('sleep_entries', orderBy: 'date DESC');
  }

  Future<List<Map<String, dynamic>>> getSleepInRange(DateTime start, DateTime end) async {
    final db = await instance.database;
    return await db.query(
      'sleep_entries',
      where: 'date BETWEEN ? AND ?',
      whereArgs: [start.toIso8601String(), end.toIso8601String()],
      orderBy: 'date ASC',
    );
  }

  Future<int> deleteSleep(int id) async {
    final db = await instance.database;
    return await db.delete('sleep_entries', where: 'id = ?', whereArgs: [id]);
  }

  // -- EXERCISES --
  Future<List<Map<String, dynamic>>> getExercisesByGroup(String group) async {
    final db = await instance.database;
    return await db.query('exercises', where: 'muscle_group = ?', whereArgs: [group], orderBy: 'name ASC');
  }

  Future<List<Map<String, dynamic>>> getAllExercises() async {
    final db = await instance.database;
    return await db.query('exercises', orderBy: 'muscle_group ASC, name ASC');
  }

  Future<int> insertExercise(String name, String group) async {
    final db = await instance.database;
    return await db.insert('exercises', {
      'name': name,
      'muscle_group': group,
      'is_custom': 1,
    });
  }

  Future<int> deleteExercise(int id) async {
    final db = await instance.database;
    return await db.delete('exercises', where: 'id = ? AND is_custom = 1', whereArgs: [id]);
  }

  // -- WORKOUTS --
  Future<int> insertSession(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('workout_sessions', row);
  }

  Future<int> insertSet(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('workout_sets', row);
  }

  Future<List<Map<String, dynamic>>> getAllSessions() async {
    final db = await instance.database;
    return await db.query('workout_sessions', orderBy: 'date DESC');
  }

  Future<List<Map<String, dynamic>>> getSetsForSession(int sessionId) async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT ws.*, e.name as exercise_name, e.muscle_group
      FROM workout_sets ws
      JOIN exercises e ON ws.exercise_id = e.id
      WHERE ws.session_id = ?
      ORDER BY e.name, ws.set_number
    ''', [sessionId]);
  }

  Future<int> deleteSession(int id) async {
    final db = await instance.database;
    await db.delete('workout_sets', where: 'session_id = ?', whereArgs: [id]);
    return await db.delete('workout_sessions', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, dynamic>?> getMaxWeightForExercise(int exerciseId) async {
    final db = await instance.database;
    final result = await db.rawQuery('''
      SELECT ws.weight, ws.reps, wsess.date
      FROM workout_sets ws
      JOIN workout_sessions wsess ON ws.session_id = wsess.id
      WHERE ws.exercise_id = ?
      ORDER BY ws.weight DESC, ws.reps DESC
      LIMIT 1
    ''', [exerciseId]);
    if (result.isEmpty) return null;
    return result.first;
  }

  Future<List<Map<String, dynamic>>> getProgressForExercise(int exerciseId) async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT MAX(ws.weight) as max_weight, wsess.date
      FROM workout_sets ws
      JOIN workout_sessions wsess ON ws.session_id = wsess.id
      WHERE ws.exercise_id = ?
      GROUP BY wsess.date
      ORDER BY wsess.date ASC
    ''', [exerciseId]);
  }

  // -- NOTES --
  Future<int> insertNote(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('notes', row);
  }

  Future<List<Map<String, dynamic>>> getAllNotes() async {
    final db = await instance.database;
    return await db.query('notes', orderBy: 'date DESC');
  }

  Future<int> updateNote(int id, Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.update('notes', row, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteNote(int id) async {
    final db = await instance.database;
    return await db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }

  // -- BODY WEIGHT --
  Future<int> insertBodyWeight(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('body_weight', row);
  }

  Future<List<Map<String, dynamic>>> getAllBodyWeight() async {
    final db = await instance.database;
    return await db.query('body_weight', orderBy: 'date DESC');
  }

  Future<int> deleteBodyWeight(int id) async {
    final db = await instance.database;
    return await db.delete('body_weight', where: 'id = ?', whereArgs: [id]);
  }

  // -- EXPORT/IMPORT --
  Future<Map<String, dynamic>> exportAllData() async {
    final db = await instance.database;
    return {
      'sleep_entries': await db.query('sleep_entries'),
      'exercises': await db.query('exercises'),
      'workout_sessions': await db.query('workout_sessions'),
      'workout_sets': await db.query('workout_sets'),
      'notes': await db.query('notes'),
      'body_weight': await db.query('body_weight'),
      'export_date': DateTime.now().toIso8601String(),
    };
  }

  Future<void> importAllData(Map<String, dynamic> data) async {
    final db = await instance.database;
    final batch = db.batch();
    batch.delete('workout_sets');
    batch.delete('workout_sessions');
    batch.delete('sleep_entries');
    batch.delete('notes');
    batch.delete('body_weight');
    batch.delete('exercises');
    await batch.commit();

    final batch2 = db.batch();
    for (final row in (data['exercises'] as List)) {
      batch2.insert('exercises', Map<String, dynamic>.from(row));
    }
    for (final row in (data['sleep_entries'] as List)) {
      batch2.insert('sleep_entries', Map<String, dynamic>.from(row));
    }
    for (final row in (data['workout_sessions'] as List)) {
      batch2.insert('workout_sessions', Map<String, dynamic>.from(row));
    }
    for (final row in (data['workout_sets'] as List)) {
      batch2.insert('workout_sets', Map<String, dynamic>.from(row));
    }
    for (final row in (data['notes'] as List)) {
      batch2.insert('notes', Map<String, dynamic>.from(row));
    }
    for (final row in (data['body_weight'] as List)) {
      batch2.insert('body_weight', Map<String, dynamic>.from(row));
    }
    await batch2.commit();
  }
}
