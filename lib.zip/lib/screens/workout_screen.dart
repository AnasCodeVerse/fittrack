import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/theme.dart';
import '../db/db_helper.dart';
import 'workout_log_screen.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  List<Map<String, dynamic>> _sessions = [];

  static const Map<String, IconData> groupIcons = {
    'Chest': Icons.shield_rounded,
    'Back': Icons.accessibility_new_rounded,
    'Triceps': Icons.fitness_center_rounded,
    'Biceps': Icons.sports_martial_arts_rounded,
    'Shoulders': Icons.expand_rounded,
  };

  static const Map<String, Color> groupColors = {
    'Chest': AppTheme.coral,
    'Back': AppTheme.lavender,
    'Triceps': AppTheme.peach,
    'Biceps': AppTheme.limeAccent,
    'Shoulders': Color(0xFF7BCDFF),
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await DBHelper.instance.getAllSessions();
    setState(() => _sessions = s);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppTheme.limeAccent,
          backgroundColor: AppTheme.surface,
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                'Workout',
                style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1),
              ),
              const SizedBox(height: 4),
              const Text(
                'Pick what you trained today',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 14),
              ),
              const SizedBox(height: 24),

              // Muscle group cards
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.4,
                children: groupIcons.keys
                    .map((g) => _MuscleGroupCard(
                          name: g,
                          icon: groupIcons[g]!,
                          color: groupColors[g]!,
                          onTap: () => _startSession(g),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 12),
              // Multi-group quick start
              InkWell(
                onTap: () => _showMultiGroupPicker(),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppTheme.limeAccent, width: 1.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.add_circle_outline_rounded,
                          color: AppTheme.limeAccent, size: 22),
                      const SizedBox(width: 10),
                      const Text(
                        'Train multiple groups',
                        style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w600,
                            fontSize: 14),
                      ),
                      const Spacer(),
                      const Icon(Icons.arrow_forward_rounded,
                          color: AppTheme.limeAccent, size: 18),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 28),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  'Workout history',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 12),
              if (_sessions.isEmpty)
                Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: AppTheme.cardDark,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Column(
                    children: [
                      Icon(Icons.fitness_center_rounded,
                          color: AppTheme.textMuted, size: 40),
                      SizedBox(height: 12),
                      Text('No workouts logged yet',
                          style: TextStyle(
                              color: AppTheme.textSecondary,
                              fontWeight: FontWeight.w600)),
                      SizedBox(height: 4),
                      Text('Pick a muscle group above to start',
                          style: TextStyle(
                              color: AppTheme.textMuted, fontSize: 12)),
                    ],
                  ),
                )
              else
                ..._sessions.map((s) => _SessionTile(
                      session: s,
                      onTap: () => _viewSession(s),
                      onDelete: () => _confirmDelete(s),
                    )),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _startSession(String group) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WorkoutLogScreen(muscleGroups: [group]),
      ),
    );
    if (result == true) _load();
  }

  Future<void> _showMultiGroupPicker() async {
    final selected = <String>{};
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                          color: AppTheme.divider,
                          borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text('Select muscle groups',
                      style:
                          TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 16),
                  ...groupIcons.keys.map((g) {
                    final isSel = selected.contains(g);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: InkWell(
                        onTap: () => setSheet(() {
                          if (isSel) {
                            selected.remove(g);
                          } else {
                            selected.add(g);
                          }
                        }),
                        borderRadius: BorderRadius.circular(16),
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: isSel
                                ? AppTheme.limeAccent.withOpacity(0.18)
                                : AppTheme.surfaceLight,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSel
                                  ? AppTheme.limeAccent
                                  : Colors.transparent,
                              width: 1.5,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(groupIcons[g],
                                  color: groupColors[g], size: 22),
                              const SizedBox(width: 14),
                              Text(g,
                                  style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600)),
                              const Spacer(),
                              if (isSel)
                                const Icon(Icons.check_circle_rounded,
                                    color: AppTheme.limeAccent),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton(
                      onPressed: selected.isEmpty
                          ? null
                          : () async {
                              Navigator.pop(ctx);
                              final result = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => WorkoutLogScreen(
                                      muscleGroups: selected.toList()),
                                ),
                              );
                              if (result == true) _load();
                            },
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18))),
                      child: Text('Start (${selected.length})',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  Future<void> _viewSession(Map<String, dynamic> session) async {
    final sets =
        await DBHelper.instance.getSetsForSession(session['id'] as int);
    if (!mounted) return;

    // Group sets by exercise
    final Map<String, List<Map<String, dynamic>>> grouped = {};
    for (final s in sets) {
      final name = s['exercise_name'] as String;
      grouped.putIfAbsent(name, () => []).add(s);
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) {
        final date = DateTime.tryParse(session['date'] as String);
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          minChildSize: 0.4,
          maxChildSize: 0.95,
          expand: false,
          builder: (ctx, scroll) => SingleChildScrollView(
            controller: scroll,
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: AppTheme.divider,
                        borderRadius: BorderRadius.circular(4)),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  date != null
                      ? DateFormat('EEEE, MMM d, y').format(date)
                      : 'Workout',
                  style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5),
                ),
                const SizedBox(height: 6),
                Text(
                  session['muscle_groups'] as String? ?? '',
                  style: const TextStyle(
                      color: AppTheme.lavender, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 20),
                if (grouped.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 32),
                    child: Center(
                        child: Text('No sets recorded',
                            style: TextStyle(color: AppTheme.textMuted))),
                  ),
                ...grouped.entries.map((entry) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.cardDark,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(entry.key,
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 15)),
                        const SizedBox(height: 10),
                        ...entry.value.asMap().entries.map((e) {
                          final set = e.value;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Container(
                                  width: 28,
                                  height: 28,
                                  decoration: BoxDecoration(
                                    color: AppTheme.surfaceLight,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    '${e.key + 1}',
                                    style: const TextStyle(
                                        color: AppTheme.limeAccent,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  '${set['reps']} reps',
                                  style: const TextStyle(
                                      color: AppTheme.textPrimary,
                                      fontSize: 14),
                                ),
                                const Spacer(),
                                Text(
                                  '${(set['weight'] as num).toStringAsFixed(set['weight'] == set['weight'].toInt() ? 0 : 1)} kg',
                                  style: const TextStyle(
                                      color: AppTheme.limeAccent,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 14),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  );
                }),
                if (session['note'] != null &&
                    (session['note'] as String).isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceLight,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.notes_rounded,
                            color: AppTheme.textMuted, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                            child: Text(session['note'] as String,
                                style: const TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontSize: 13))),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _confirmDelete(Map<String, dynamic> session) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete workout?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        content: const Text('This will remove all sets logged in this session.',
            style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel',
                  style: TextStyle(color: AppTheme.textMuted))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Delete',
                  style: TextStyle(
                      color: AppTheme.error, fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (ok == true) {
      await DBHelper.instance.deleteSession(session['id'] as int);
      _load();
    }
  }
}

class _MuscleGroupCard extends StatelessWidget {
  final String name;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _MuscleGroupCard(
      {required this.name,
      required this.icon,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.cardDark,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.18),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 16)),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceLight,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(Icons.arrow_forward_rounded,
                      size: 14, color: AppTheme.textPrimary),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SessionTile extends StatelessWidget {
  final Map<String, dynamic> session;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  const _SessionTile(
      {required this.session, required this.onTap, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final date = DateTime.tryParse(session['date'] as String);
    final groups = session['muscle_groups'] as String? ?? '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.cardDark,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.limeAccent.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.fitness_center_rounded,
                    color: AppTheme.limeAccent, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      date != null
                          ? DateFormat('EEE, MMM d').format(date)
                          : '—',
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    const SizedBox(height: 2),
                    Text(groups,
                        style: const TextStyle(
                            color: AppTheme.textMuted, fontSize: 12)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onDelete,
                child: const Padding(
                  padding: EdgeInsets.all(6),
                  child: Icon(Icons.delete_outline,
                      color: AppTheme.textMuted, size: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
